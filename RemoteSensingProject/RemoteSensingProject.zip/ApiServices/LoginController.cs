﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using Newtonsoft.Json;
using RemoteSensingProject.Models;
using RemoteSensingProject.Models.Admin;
using RemoteSensingProject.Models.LoginManager;
using static RemoteSensingProject.Models.Admin.main;
using static RemoteSensingProject.Models.LoginManager.main;

namespace RemoteSensingProject.ApiServices
{
    [JwtAuthorize]
    public class LoginController : ApiController
    {
        private readonly LoginServices _loginService;
        private readonly AdminServices _adminServices;
        public LoginController()
        {
            _loginService = new LoginServices();
            _adminServices = new AdminServices();   
        }
        #region Login Api
        [System.Web.Mvc.AllowAnonymous]
        [HttpPost]
        [Route("api/login")]
        public IHttpActionResult Login()
        {
            try
            {

                var request = HttpContext.Current.Request;
                string username = request.Form.Get("username");
                string password = request.Form.Get("password");
                if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                {
                    return BadRequest(new
                    {
                        status = false,
                        StatusCode = 400,
                        Message = "Username and password are required."
                    });
                }
                Credentials data = _loginService.Login(username, password);

                if (username.Equals(data.username) && password.Equals(data.password))
                {
                    string token = _loginService.GenerateToken(data);
                    var userData = new
                    {
                        username = data.username,
                        Emp_Id = data.Emp_Id,
                        Emp_Name = data.Emp_Name,
                        profilePath = data.profilePath,
                        role = data.role,
                        userId = data.userId
                    };
                    return Ok(new
                    {
                        status = true,
                        StatusCode = 200,
                        data = userData,
                        token = token
                    });
                }
                return BadRequest(new
                {
                    status = false,
                    StatusCode = 400,
                    message = "Invalid userid or password."
                });
            }
            catch (Exception ex)
            {
                return BadRequest(new
                {
                    status = false,
                    StatusCode = 500,
                    message = ex.Message,
                    data = ex
                });
            }
        }
        private IHttpActionResult BadRequest(object value)
        {
            return Content(HttpStatusCode.BadRequest, value);
        }
        #endregion

        [RoleAuthorize("admin,projectManager")]
        [HttpGet]
        [Route("api/getresult")]
        public IHttpActionResult GetResult()
        {
            try
            {
                return Ok(new
                {
                    status = true,
                    StatusCode = 200,
                    Message = "Welcome to Api"
                });
            }
            catch
            {
                return BadRequest(new
                {
                    status = false,
                    StatusCode = 500,
                    Message = "baba ji ka thullu"
                });
            }
        }

        #region Add Project
        [RoleAuthorize("admin,projectManager")]
        [HttpPost]
        [Route("api/adminCreateProject")]
        public IHttpActionResult CreateProject()
        {
            List<string> savedFiles = new List<string>();
            try
            {
                var request = HttpContext.Current.Request;
                var form = request.Form;
                var files = request.Files;

                // ✅ Initialize main model
                var model = new createProjectModel();
                model.pm = new Project_model();

                model.pm.Id = Convert.ToInt32(form["Id"] ?? "0");
                model.pm.ProjectTitle = form["ProjectTitle"];
                model.pm.ProjectManager = form["ProjectManager"];
                model.pm.ProjectDescription = form["ProjectDescription"];
                model.pm.ProjectType = form["ProjectType"];
                model.pm.letterNo = form["letterNo"] ?? "0";
                if (!Boolean.TryParse(form["createdBy"], out var createdBy))
                    return CommonHelper.Error(this, "Created By is required", 500);
                model.pm.createdBy = form["createdBy"].ToString();

                // Project Stages
                if (!Boolean.TryParse(form["projectStage"], out var projectStages))
                    return CommonHelper.Error(this, "Project Stages is required", 500);
                model.pm.ProjectStage = projectStages;

                // ✅ Dates
                if (!DateTime.TryParse(form["AssignDate"], out var assignDate))
                    return CommonHelper.Error(this, "Assign Date is required.", 500);
                model.pm.AssignDate = assignDate;

                if (!DateTime.TryParse(form["StartDate"], out var startDate))
                    return CommonHelper.Error(this, "Start Date is required.", 500);
                model.pm.StartDate = startDate;

                if (!DateTime.TryParse(form["CompletionDate"], out var compDate))
                    return CommonHelper.Error(this, "Completion Date is required.", 500);
                model.pm.CompletionDate = compDate;

                // ✅ Budget
                if (!decimal.TryParse(form["ProjectBudget"], out var budget))
                    return CommonHelper.Error(this, "Invalid Project Budget", 500);
                model.pm.ProjectBudget = budget;

                // ✅ External Project Extra Fields
                if (model.pm.ProjectType?.ToLower() == "external")
                {
                    model.pm.ContactPerson = form["ContactPerson"];
                    model.pm.ProjectDepartment = form["ProjectDepartment"];
                    model.pm.Address = form["Address"];
                }

                // ✅ Subordinates (ID list)
                if (!string.IsNullOrEmpty(form["SubOrdinate"]))
                {
                    model.pm.SubOrdinate =
                        form["SubOrdinate"]
                        .Split(',')
                        .Select(int.Parse)
                        .ToArray();
                }

                // ✅ Parse budgets JSON
                if (!string.IsNullOrEmpty(form["budgets"]))
                {
                    model.budgets = JsonConvert.DeserializeObject<List<Project_Budget>>(form["budgets"]);

                    // ✅ Validate sum of ProjectAmount ≤ ProjectBudget
                    if (model.budgets != null && model.budgets.Any())
                    {
                        decimal totalBudgetAmount = model.budgets.Sum(b => b.ProjectAmount);
                        if (totalBudgetAmount > model.pm.ProjectBudget)
                        {
                            return CommonHelper.Error(this,
                                $"Total of all ProjectAmounts ({totalBudgetAmount}) cannot exceed the main ProjectBudget ({model.pm.ProjectBudget}).",
                                400);
                        }
                    }
                }

                // ✅ Parse stages JSON
                if (!string.IsNullOrEmpty(form["stages"]) && model.pm.ProjectStage)
                {
                    model.stages = JsonConvert.DeserializeObject<List<Project_Statge>>(form["stages"]);
                }

                // ✅ Upload Project Document (single)
                string filePage = HttpContext.Current.Server.MapPath("~/ProjectContent/Admin/ProjectDocs/");
                if (!Directory.Exists(filePage))
                    Directory.CreateDirectory(filePage);
                var projectFile = files["projectDocument"];
                if (projectFile != null && projectFile.ContentLength > 0)
                {
                    string fileName = DateTime.Now.ToString("ddMMyyyy") + "_" + Guid.NewGuid()
                                      + Path.GetExtension(projectFile.FileName);
                    string filePath = "/ProjectContent/Admin/ProjectDocs/" + fileName;

                    model.pm.projectDocumentUrl = filePath;
                    projectFile.SaveAs(HttpContext.Current.Server.MapPath(filePath));
                    savedFiles.Add(filePath);
                }

                // ✅ Upload Stage Documents (multiple)
                if (model.stages != null && model.pm.ProjectStage)
                {
                    for (int i = 0; i < model.stages.Count; i++)
                    {
                        var stageFile = files["StageDocument_" + i];
                        if (stageFile != null && stageFile.ContentLength > 0)
                        {
                            string fileName = "STAGE_" + i + "_" + DateTime.Now.ToString("ddMMyyyy")
                                              + "_" + Guid.NewGuid() + Path.GetExtension(stageFile.FileName);

                            string filePath = "/ProjectContent/Admin/ProjectDocs/" + fileName;

                            // ✅ Save file
                            stageFile.SaveAs(HttpContext.Current.Server.MapPath(filePath));

                            // ✅ Store URL in model
                            model.stages[i].StageDocument_Url = filePath;
                            savedFiles.Add(filePath);
                        }
                    }
                }

                // ✅ Save project in DB
                bool result = _adminServices.addProject(model);

                if (result)
                {
                    return CommonHelper.Success(this, "Project created successfully!");
                }
                else
                {
                    return CommonHelper.Error(this, "Something went wrong.", 500);
                }
            }
            catch (Exception ex)
            {
                foreach (var f in savedFiles)
                {
                    if (File.Exists(f))
                        File.Delete(f);
                }
                return CommonHelper.Error(this, ex.Message, 500);

            }
        }

        [RoleAuthorize("admin,projectManager")]
        [HttpGet]
        [Route("api/GetadminProjectDetailById")]
        public IHttpActionResult GetProjectById(int Id)
        {
            try
            {
                var data = _adminServices.GetProjectById(Id);
                return Ok(new
                {
                    status = true,
                    data = data
                });
            }
            catch (Exception ex)
            {
                return BadRequest(new
                {
                    status = false,
                    StatusCode = 500,
                    message = ex.Message
                });
            }
        }

        #endregion

        #region Add Meeting
        [RoleAuthorize("admin,projectManager")]
        [HttpPost]
        [Route("api/adminCreateMeeting")]
        public IHttpActionResult CreateMeeting()
        {
            try
            {
                var request = HttpContext.Current.Request;
                List<string> validationErrors = new List<string>();
                if (string.IsNullOrWhiteSpace(request.Form.Get("MeetingType")))
                    validationErrors.Add("Meeting Type is required.");


                if (string.IsNullOrWhiteSpace(request.Form.Get("MeetingTitle")))
                    validationErrors.Add("Meeting title is required.");

                if (string.IsNullOrWhiteSpace(request.Form.Get("MeetingTime")))
                    validationErrors.Add("Meeting time is required.");

                if (string.IsNullOrWhiteSpace(request.Form.Get("meetingMemberList")))
                    validationErrors.Add("Meeting member is required.");

                if (string.IsNullOrWhiteSpace(request.Form.Get("keyPointList")))
                    validationErrors.Add("Key points is required.");

                var formData = new AddMeeting_Model
                {
                    // For Id, use TryParse to avoid invalid format error
                    Id = int.TryParse(request.Form.Get("Id"), out var id) ? id : 0,

                    // For MeetingType, MeetingLink, MeetingTitle, MeetingAddress, use null coalescing operator for string defaults
                    MeetingType = request.Form.Get("MeetingType") ?? string.Empty,
                    MeetingLink = request.Form.Get("MeetingLink") ?? string.Empty,
                    MeetingTitle = request.Form.Get("MeetingTitle") ?? string.Empty,
                    MeetingAddress = request.Form.Get("MeetingAddress") ?? string.Empty,

                    // For MeetingTime, use DateTime.TryParse to avoid invalid format error
                    MeetingTime = DateTime.TryParse(request.Form.Get("MeetingTime"), out var meetingTime) ? meetingTime : DateTime.MinValue,

                    // For Attachment_Url, use null coalescing operator to default to empty string if null
                    Attachment_Url = request.Form.Get("Attachment_Url") ?? string.Empty,

                    // For CreaterId, use TryParse to handle invalid formats
                    CreaterId = int.TryParse(request.Form.Get("CreaterId"), out var createrId) ? createrId : 0
                };
                string filePage = HttpContext.Current.Server.MapPath("~/ProjectContent/Admin/Meeting_Attachment/");
                if (!Directory.Exists(filePage))
                    Directory.CreateDirectory(filePage);
                var file = request.Files["Attachment"];
                if (file != null && file.FileName != "")
                {
                    formData.Attachment_Url = DateTime.Now.ToString("ddMMyyyy") + Guid.NewGuid().ToString() + Path.GetExtension(file.FileName);
                    formData.Attachment_Url = Path.Combine("/ProjectContent/Admin/Meeting_Attachment/", formData.Attachment_Url);
                }
                else if (string.IsNullOrWhiteSpace(request.Form.Get("Attachment_Url")))
                    validationErrors.Add("Meeting attachment is required.");

                if (request.Form["meetingMemberList"] != null)
                {
                    formData.meetingMemberList = request.Form["meetingMemberList"] != null ? request.Form["meetingMemberList"].Split(',').Select(value => int.Parse(value.ToString())).ToList() : new List<int>();
                }

                if (request.Form["keyPointList"] != null)
                {
                    formData.keyPointList = request.Form["keyPointList"].Split(',').ToList();
                }

                if (validationErrors.Any())
                {
                    return BadRequest(new
                    {
                        status = false,
                        StatusCode = 500,
                        message = string.Join("\n", validationErrors)
                    });
                }
                bool res = _adminServices.insertMeeting(formData);
                if (res)
                {
                    if (file != null && file.FileName != "")
                    {
                        file.SaveAs(HttpContext.Current.Server.MapPath(formData.Attachment_Url));
                    }
                }
                return Ok(new
                {
                    status = res,
                    StatusCode = res ? formData.Id > 0 ? 200 : 201 : 500,
                    message = res ? formData.Id > 0 ? "Meeting updated successfully" : "Meeting created successfully !" : "Some issue occured while processing request."
                });
            }
            catch (Exception ex)
            {
                return BadRequest(new
                {
                    status = false,
                    StatusCode = 500,
                    message = ex.Message
                });
            }
        }

        [RoleAuthorize("admin,projectManager")]
        [HttpGet]
        [Route("api/GetMeetingById")]
        public IHttpActionResult GetMeetingById(int Id)
        {
            try
            {
                var data = _adminServices.getMeetingById(Id);
                return Ok(new
                {
                    status = true,
                    StatusCode = 200,
                    data = data
                });
            }
            catch (Exception ex)
            {
                return BadRequest(new
                {
                    status = false,
                    StatusCode = 500,
                    message = ex.Message
                });
            }
        }
        #endregion

    }
}
